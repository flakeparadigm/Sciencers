package model.inventory;

public interface Storable {

}
