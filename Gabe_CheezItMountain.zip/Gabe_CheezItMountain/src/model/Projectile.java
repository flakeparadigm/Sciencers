package model;

import java.io.Serializable;

public class Projectile implements Serializable {

}
